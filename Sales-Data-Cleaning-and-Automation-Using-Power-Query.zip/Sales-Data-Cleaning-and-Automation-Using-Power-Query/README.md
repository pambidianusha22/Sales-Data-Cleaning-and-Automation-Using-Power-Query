# Sales Data Cleaning and Automation Using Power Query

## Project Overview

This project demonstrates how Microsoft Excel Power Query can be used to prepare sales data for analysis. The project focuses on organizing sales records so that the data can support year-wise and customer-wise payment analysis.

The intended business question is:

> \*\*For each year, how much did each customer pay?\*\*

Power Query is used to clean and transform the source data, combine multiple datasets into one consolidated dataset, and reuse the saved transformation steps when new data arrives.

## Project Objectives

* Prepare sales data for customer-wise and year-wise analysis.
* Remove columns that are not required for the analysis.
* Restructure fields by merging and splitting columns where needed.
* Clean and standardize the dataset.
* Combine multiple datasets into a consolidated dataset.
* Use Refresh to reapply the saved query steps when the source data is updated or new data is added.
* Prepare the resulting data for further analysis and visualization.

## Tools Used

* Microsoft Excel
* Power Query Editor

## Workflow

1. **Import the source data:** Bring the sales data into Microsoft Excel and open it in Power Query Editor.
2. **Inspect the data:** Review the available columns and identify fields needed for customer-wise and year-wise payment analysis.
3. **Clean the data:** Remove unnecessary columns and carry out the required cleaning operations.
4. **Transform the data:** Merge or split columns as required to organize the information.
5. **Combine datasets:** Consolidate the multiple sales datasets into one dataset using the appropriate Power Query operation for the source structure.
6. **Load the result:** Use Close \& Load to load the transformed data back into Excel.
7. **Refresh for new data:** When new records are added to the connected source, refresh the query to reapply the saved transformation steps.

## Key Power Query Operations

|Operation|Purpose in this project|
|-|-|
|Remove Columns|Exclude fields that are not needed for the analysis.|
|Merge Columns|Combine selected fields when a single field is required.|
|Split Column|Divide a field into separate columns when its values contain multiple pieces of information.|
|Data Cleaning and Transformation|Prepare the source records in a consistent structure.|
|Combine Datasets|Bring multiple datasets together into one consolidated dataset.|
|Refresh|Re-run the saved query steps against updated source data.|

**Note:** The exact operations and their order should match the steps actually applied in the workbook. Do not list an operation as completed unless it was performed.

## Repository Structure

```text
Sales-Data-Cleaning-and-Automation-Using-Power-Query/
├── README.md
├── Dataset/
│   ├── Original\_Sales\_Data.xlsx
│   └── Cleaned\_Sales\_Data.xlsx
├── Screenshots/
│   ├── Original\_Data.png
│   ├── Data\_Cleaning.png
│   └── Final\_Output.png
└── Documentation/
    └── Project\_Description.pdf
```

## Files

* `Original\_Sales\_Data.xlsx` — source dataset used for the project.
* `Cleaned\_Sales\_Data.xlsx` — cleaned output, if saved separately.
* `Screenshots/` — screenshots showing the original data, transformation process, and final output.

## Expected Analysis Output

The prepared dataset is intended to support analysis of:

* Customer
* Year
* Amount paid

The exact column names depend on the source dataset. A year-wise, customer-wise summary or visualization can be created from the cleaned data if that analysis has been completed.

## How to Use

1. Download or clone this repository.
2. Open the query-enabled Excel workbook in `Power\_Query/`.
3. If the workbook uses external source files, place the source data in the expected location and update the source path if required.
4. In Excel, use **Data → Refresh All** (or the relevant query refresh option) to rerun the saved transformations.
5. Review the refreshed output and verify that the new records are included correctly.

## Validation Checklist

Before sharing the project, verify that:

* The source data and final output are both included, if permitted.
* The query-enabled workbook opens without broken source paths.
* Refresh works with a representative updated source file.
* Customer names, years, and payment amounts are correctly typed and populated.
* The final output does not contain unintended duplicate or missing records.
* Screenshots are genuine captures from your own workbook.
* No confidential, personal, or commercially sensitive information is exposed.

## Limitations and Notes

* The accuracy of the analysis depends on the quality and structure of the source data.
* Refresh re-runs the saved transformation steps; it does not automatically discover every possible new file unless the query has been configured to read from a folder or another changing source.
* This repository describes data preparation and automation. Add claims about dashboards, charts, totals, or business findings only after creating and verifying them.

## Author

**Name:** \[pambidi.anusha]  
**LinkedIn:** \[https://www.linkedin.com/in/pambidi-anusha]  
**GitHub:** \[https://github.com/pambidianusha22]

## 

